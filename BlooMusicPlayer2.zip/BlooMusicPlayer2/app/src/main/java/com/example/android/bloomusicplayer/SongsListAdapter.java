package com.example.android.bloomusicplayer;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.android.bloomusicplayer.audiocover.AudioCover;

import java.util.ArrayList;

/**
 * Created by 5biin-14 on 31/05/2018.
 */


public class SongsListAdapter extends ArrayAdapter<Song> {
    private Context mContext;
    AlbumCache mAlbumCache;

    SongsListAdapter(Context mContext, int songlistitem, ArrayList<Song> songs) {
        super(mContext, songlistitem, songs);
        this.mContext = mContext;
        mAlbumCache = new AlbumCache();
    }

    @SuppressLint({"InflateParams", "StaticFieldLeak"})
    @NonNull
    @Override
    public View getView(final int position, View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        SongItemHolder songItemHolder;


        if (v == null) {
            LayoutInflater vi;
            vi = LayoutInflater.from(getContext());
            v = vi.inflate(R.layout.songlistitem, null);

            songItemHolder = new com.example.android.bloomusicplayer.SongItemHolder();
            songItemHolder.albumart = (ImageView) v.findViewById(R.id.albumart);
            songItemHolder.artist = (TextView) v.findViewById(R.id.artist);
            songItemHolder.title = (TextView) v.findViewById(R.id.title);
            songItemHolder.filepath = (TextView) v.findViewById(R.id.filepath);

            v.setTag(songItemHolder);
        } else {
            songItemHolder = (SongItemHolder) v.getTag();
        }

        final com.example.android.bloomusicplayer.Song p = getItem(position);

        if (p != null) {
            songItemHolder.title.setText(p.getTitle());
            songItemHolder.artist.setText(p.getArtist());
            songItemHolder.filepath.setText(p.getFilePath());
            songItemHolder.albumart.setTag(position);
            songItemHolder.albumart.setImageBitmap(null);
            loadBitmap(p,songItemHolder.albumart,position);
            /*AudioCover model = new AudioCover(p.getFilePath());
            Glide   .with(mContext)
                    .load(model)
                    .signature(model.signature)
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                    .placeholder(R.drawable.placeholder_coverart)
                    .error(R.drawable.placeholder_coverart)
                    .into(songItemHolder.albumart);*/


            /*new AsyncTask<ImageView, Void, Bitmap>() {
                private ImageView v;

                @Override
                protected Bitmap doInBackground(ImageView... params) {
                    v = params[0];
                    return p.getThumbnail();

                }

                @Override
                protected void onPostExecute(Bitmap result) {
                    if (isCancelled()) {
                        result = null;
                    }
                    if(result!=null && ((Integer)v.getTag())==position)
                        v.setImageBitmap(result);
                    else if(((Integer)v.getTag())==position)
                    {
                        Drawable d = mContext.getResources().getDrawable(R.drawable.placeholder_coverart);
                        v.setImageDrawable(d);
                    }

                }
            }.execute(songItemHolder.albumart);*/
        }
        return v;
    }

    public void loadBitmap(final Song mP, ImageView mImageView, final int mPosition){
        final String resId = String.valueOf(mP.getId());

        final Bitmap bitmap = mAlbumCache.getBitmapFromMemCache(resId);
        if(bitmap!=null){
            mImageView.setImageBitmap(bitmap);
        } else {
            mImageView.setImageBitmap(null);
            new AsyncTask<ImageView, Void, Bitmap>() {
                private ImageView v;

                @Override
                protected Bitmap doInBackground(ImageView... params) {
                    v = params[0];
                    return mP.getThumbnail();

                }

                @Override
                protected void onPostExecute(Bitmap result) {
                    if (isCancelled()) {
                        result = null;
                    }
                    if (result != null && (Integer)v.getTag()== getPosition(mP)){
                        v.setImageBitmap(result);
                        mAlbumCache.addBitmapToMemoryCache(String.valueOf(resId),result);
                    }
                    else if((Integer)v.getTag()== getPosition(mP))
                    {
                        Drawable d = mContext.getResources().getDrawable(R.drawable.placeholder_coverart);
                        v.setImageDrawable(d);
                    }

                }
            }.execute(mImageView);
        }
    }
}
