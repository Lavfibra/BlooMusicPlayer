package com.example.android.bloomusicplayer;

import android.widget.ImageView;
import android.widget.TextView;

public class SongItemHolder{
    public ImageView albumart;
    public TextView title;
    public TextView artist;
    public TextView filepath;

}