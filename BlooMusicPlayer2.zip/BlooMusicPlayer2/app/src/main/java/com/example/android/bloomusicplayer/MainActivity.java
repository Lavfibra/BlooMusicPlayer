package com.example.android.bloomusicplayer;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.LruCache;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.vistrav.ask.Ask;

public class MainActivity extends AppCompatActivity {
    SongList mSongsList = new SongList();
    MediaPlayer mMediaPlayer;
    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            Ask.on(this)
                    .id(1) // in case you are invoking multiple time Ask from same activity or fragment
                    .forPermissions(Manifest.permission.READ_EXTERNAL_STORAGE
                            , Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    .withRationales("Reading External storage needed for songs searching",
                            "In order to save playlists and changing metadata you will need Write External Storage") //optional
                    .go();
        }




        SongTask songTask = new SongTask(this,findViewById(R.id.activity_main));
        songTask.execute(mSongsList);

        ListView songslist = (ListView)findViewById(R.id.songslist);
        songslist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                releaseMediaPlayer();
                TextView filepath = view.findViewById(R.id.filepath);
                String path = (String) filepath.getText();
                Toast.makeText(MainActivity.this,path,Toast.LENGTH_LONG).show();
                mMediaPlayer = MediaPlayer.create(MainActivity.this,Uri.parse(path));
                mMediaPlayer.setLooping(true);
                mMediaPlayer.start();
            }
        });
    }

    private void releaseMediaPlayer() {
        // If the media player is not null, then it may be currently playing a sound.
        if (mMediaPlayer != null) {
            // Regardless of the current state of the media player, release its resources
            // because we no longer need it.
            mMediaPlayer.release();

            // Set the media player back to null. For our code, we've decided that
            // setting the media player to null is an easy way to tell that the media player
            // is not configured to play an audio file at the moment.
            mMediaPlayer = null;
        }
    }
}
