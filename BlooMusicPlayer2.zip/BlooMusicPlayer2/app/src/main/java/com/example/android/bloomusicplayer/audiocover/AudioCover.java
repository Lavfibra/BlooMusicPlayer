package com.example.android.bloomusicplayer.audiocover;

public class AudioCover {
    final public String path;
    final public AudioCoverSignature signature;
    public AudioCover(String path) {
        this.path = path;
        this.signature = new AudioCoverSignature(path);
        // this list creation should already be in the background (Loader?),
        // so it's fine to call blocking I/O there
        signature.refresh();
    }
}