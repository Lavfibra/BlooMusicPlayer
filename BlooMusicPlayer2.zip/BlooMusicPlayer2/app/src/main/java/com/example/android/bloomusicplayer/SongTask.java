package com.example.android.bloomusicplayer;

import android.content.Context;
import android.os.AsyncTask;
import android.view.View;
import android.widget.ListView;

import com.example.android.bloomusicplayer.R;
import com.example.android.bloomusicplayer.Song;
import com.example.android.bloomusicplayer.SongList;

import java.util.ArrayList;

/**
 * Created by 5biin-14 on 31/05/2018.
 */

public class SongTask extends AsyncTask<SongList, String, SongList>{
    private Context mContext;
    private SongList mSongList;
    private View mRootView;


    public SongTask(Context context,View rootView){
        mContext=context;
        mRootView=rootView;
    }

    @Override
    protected SongList doInBackground(SongList... songLists) {
        mSongList= (SongList)songLists[0];
        mSongList.scanSongs(mContext,"external");
        return null;
    }

    @Override
    protected void onPostExecute(SongList songList) {
        ArrayList<Song> songs = mSongList.getSongs();

        ListView yourListView = (ListView)mRootView.findViewById(R.id.songslist);
        // get data from the table by the ListAdapter
        SongsListAdapter customAdapter = new SongsListAdapter(mContext, R.layout.songlistitem, songs) {
        };

        yourListView .setAdapter(customAdapter);
    }
}
